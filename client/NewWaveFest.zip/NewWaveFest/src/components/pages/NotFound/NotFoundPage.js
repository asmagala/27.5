import React from 'react';

const NotFoundPage = () => (
  <div>
    <h1>404 Not Found</h1>
  </div>
);

export default NotFoundPage;
